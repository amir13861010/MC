<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\VoucherController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\UserHierarchyController;
use App\Http\Controllers\LegBalanceController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\WithdrawalRequestController;
use App\Http\Controllers\RewardController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\DepositController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Test route
Route::get('test', function () {
    return response()->json(['message' => 'API routes are working!']);
});

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_middleware'),
    'verified'
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});
Route::put('/admin/profile', [AdminController::class, 'update']);
// Voucher routes
Route::apiResource('vouchers', VoucherController::class);
Route::get('vouchers/user/{user_id}', [VoucherController::class, 'getUserVouchers']);
Route::get('vouchers/code/{code}', [VoucherController::class, 'getVoucherByCode']);
Route::post('vouchers/redeem', [VoucherController::class, 'redeemVoucher']);

// Auth routes
Route::post('auth/sign-up', [RegisterController::class, 'register']);
Route::post('auth/login', [LoginController::class, 'login']);
Route::post('auth/decode-token', [LoginController::class, 'decodeToken']);
Route::post('register', [RegisterController::class, 'register']);
Route::post('auth/unsuspend', [LoginController::class, 'unsuspendUser']);

// User Hierarchy Routes
Route::get('users/hierarchy', [UserHierarchyController::class, 'index']);
Route::get('users/{user_id}/sub-users', [UserHierarchyController::class, 'getSubUsers']);


    Route::get('/leg-balances/{user_id}', [LegBalanceController::class, 'getLegBalances']);

// Ticket routes
Route::post('/tickets', [TicketController::class, 'store']);
Route::get('/tickets/{user_id}', [TicketController::class, 'getUserTickets']);
Route::get('/tickets/{ticket_id}', [TicketController::class, 'show']);

// Admin ticket routes
Route::get('/admin/tickets', [TicketController::class, 'adminIndex']);
Route::post('/admin/tickets/{ticket_id}/reply', [TicketController::class, 'adminReply']);

// Withdrawal Request routes
Route::post('/withdrawal-requests', [WithdrawalRequestController::class, 'store']);
Route::get('/withdrawal-requests/{user_id}', [WithdrawalRequestController::class, 'getUserRequests']);

// Admin withdrawal request routes
Route::get('/admin/withdrawal-requests', [WithdrawalRequestController::class, 'adminIndex']);
Route::post('/admin/withdrawal-requests/{request_id}/update-status', [WithdrawalRequestController::class, 'updateStatus']);
Route::post('/admin/withdrawal-requests/{request_id}/add-transaction-hash', [WithdrawalRequestController::class, 'addTransactionHash']);

// Reward routes
Route::get('/rewards/{user_id}', [RewardController::class, 'getUserRewards']);
Route::get('/rewards/{user_id}/summary', [RewardController::class, 'getUserRewardsSummary']);

// Admin management route
Route::post('/admin/add', [\App\Http\Controllers\AdminController::class, 'addAdmin']);
// Admin activate user route
Route::post('/admin/activate-user', [\App\Http\Controllers\AdminController::class, 'activateUser']);

// Enable two factor authentication for user
Route::post('/user/enable-2fa', [\App\Http\Controllers\AdminController::class, 'enableTwoFactor']);

// Change user password
Route::post('/user/change-password', [\App\Http\Controllers\AdminController::class, 'changePassword']);

// Deposit routes
Route::post('/deposits', [\App\Http\Controllers\DepositController::class, 'store']);
Route::patch('/deposits/{id}/status', [DepositController::class, 'updateStatus']);
Route::post('/users/transfer-capital-to-gain', [\App\Http\Controllers\UserController::class, 'transferCapitalToGain']);
Route::post('/users/transfer-to-user', [\App\Http\Controllers\UserController::class, 'transferToUser']);
Route::get('/users/profile', [\App\Http\Controllers\UserController::class, 'profile']);
