<?php

namespace App\Http\Controllers;

use App\Models\Deposit;
use App\Models\User;
use Illuminate\Http\Request;

class DepositController extends Controller
{
    /**
     * Store a newly created deposit in storage.
     *
     * @OA\Post(
     *     path="/api/deposits",
     *     summary="Create a new deposit",
     *     tags={"Deposits"},
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"user_id","amount","status"},
     *             @OA\Property(property="user_id", type="string", example="MC123456"),
     *             @OA\Property(property="amount", type="number", format="float", example=1000),
     *             @OA\Property(property="status", type="string", example="completed")
     *         )
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Deposit created successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="id", type="integer"),
     *             @OA\Property(property="user_id", type="string"),
     *             @OA\Property(property="amount", type="number", format="float"),
     *             @OA\Property(property="status", type="string"),
     *             @OA\Property(property="created_at", type="string", format="date-time")
     *         )
     *     ),
     *     @OA\Response(response=404, description="User not found")
     * )
     */
    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,user_id',
            'amount' => 'required|numeric|min:0.01',
            'status' => 'required|in:pending,completed,failed',
        ]);

        $user = User::where('user_id', $request->user_id)->first();
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        $deposit = Deposit::create([
            'user_id' => $user->user_id,
            'amount' => $request->amount,
            'status' => $request->status,
        ]);

        // فقط زمانی که وضعیت completed است، موجودی افزایش پیدا کند
        if ($request->status === 'completed') {
            $user->deposit_balance += $request->amount;
            $user->save();
        }

        return response()->json($deposit, 201);
    }

    /**
     * Update the status of a deposit.
     *
     * @OA\Patch(
     *     path="/api/deposits/{id}/status",
     *     summary="Update deposit status",
     *     tags={"Deposits"},
     *     security={{"bearerAuth":{}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         @OA\Schema(type="integer")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"status"},
     *             @OA\Property(property="status", type="string", example="completed")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Deposit status updated successfully"
     *     ),
     *     @OA\Response(response=404, description="Deposit not found")
     * )
     */
    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:pending,completed,failed',
        ]);

        $deposit = Deposit::find($id);
        if (!$deposit) {
            return response()->json(['message' => 'Deposit not found'], 404);
        }

        $oldStatus = $deposit->status;
        $deposit->status = $request->status;
        $deposit->save();

        // اگر وضعیت جدید completed شد و قبلاً completed نبوده
        if ($oldStatus !== 'completed' && $request->status === 'completed') {
            $user = User::where('user_id', $deposit->user_id)->first();
            if ($user) {
                $user->deposit_balance += $deposit->amount;
                $user->save();
            }
        }

        return response()->json(['message' => 'Deposit status updated successfully']);
    }
} 