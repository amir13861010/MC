<?php

namespace App\Http\Controllers;

use App\Models\WithdrawalRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

/**
 * @OA\Tag(
 *     name="Withdrawal Requests",
 *     description="API Endpoints for managing withdrawal requests"
 * )
 */
class WithdrawalRequestController extends Controller
{
    /**
     * @OA\Post(
     *     path="/api/withdrawal-requests",
     *     summary="Create a new withdrawal request",
     *     tags={"Withdrawal Requests"},
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"user_id", "wallet_address", "amount_usd", "amount_btc"},
     *             @OA\Property(property="user_id", type="string", example="MC-123456"),
     *             @OA\Property(property="wallet_address", type="string", example="1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"),
     *             @OA\Property(property="amount_usd", type="number", format="float", example=100.00),
     *             @OA\Property(property="amount_btc", type="number", format="float", example=0.00123456),
     *             @OA\Property(property="comment", type="string", example="Monthly withdrawal")
     *         )
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Withdrawal request created successfully"
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation error"
     *     )
     * )
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|exists:users,user_id',
            'wallet_address' => 'required|string|max:255',
            'amount_usd' => 'required|numeric|min:0',
            'amount_btc' => 'required|numeric|min:0',
            'comment' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $withdrawalRequest = WithdrawalRequest::create([
            'user_id' => $request->user_id,
            'wallet_address' => $request->wallet_address,
            'amount_usd' => $request->amount_usd,
            'amount_btc' => $request->amount_btc,
            'comment' => $request->comment,
            'status' => WithdrawalRequest::STATUS_IN_PROCESS
        ]);

        return response()->json([
            'message' => 'Withdrawal request created successfully',
            'withdrawal_request' => $withdrawalRequest
        ], 201);
    }

    /**
     * @OA\Get(
     *     path="/api/withdrawal-requests/{user_id}",
     *     summary="Get user's withdrawal requests",
     *     tags={"Withdrawal Requests"},
     *     security={{"bearerAuth":{}}},
     *     @OA\Parameter(
     *         name="user_id",
     *         in="path",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="List of user's withdrawal requests"
     *     )
     * )
     */
    public function getUserRequests($userId)
    {
        $requests = WithdrawalRequest::where('user_id', $userId)
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json(['withdrawal_requests' => $requests]);
    }

    /**
     * @OA\Post(
     *     path="/api/admin/withdrawal-requests/{request_id}/update-status",
     *     summary="Update withdrawal request status",
     *     tags={"Withdrawal Requests"},
     *     security={{"bearerAuth":{}}},
     *     @OA\Parameter(
     *         name="request_id",
     *         in="path",
     *         required=true,
     *         @OA\Schema(type="integer")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"status"},
     *             @OA\Property(property="status", type="string", enum={"in_queue", "in_process", "completed"})
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Status updated successfully"
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Request not found"
     *     )
     * )
     */
    public function updateStatus(Request $request, $requestId)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:in_queue,in_process,completed'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $withdrawalRequest = WithdrawalRequest::findOrFail($requestId);

        if (!$withdrawalRequest->canBeUpdated()) {
            return response()->json([
                'message' => 'Cannot update status of completed request'
            ], 400);
        }

        $withdrawalRequest->update([
            'status' => $request->status
        ]);

        return response()->json([
            'message' => 'Status updated successfully',
            'withdrawal_request' => $withdrawalRequest
        ]);
    }

    /**
     * @OA\Post(
     *     path="/api/admin/withdrawal-requests/{request_id}/add-transaction-hash",
     *     summary="Add transaction hash to withdrawal request",
     *     tags={"Withdrawal Requests"},
     *     security={{"bearerAuth":{}}},
     *     @OA\Parameter(
     *         name="request_id",
     *         in="path",
     *         required=true,
     *         @OA\Schema(type="integer")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"transaction_hash"},
     *             @OA\Property(property="transaction_hash", type="string")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Transaction hash added successfully"
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Cannot update completed request or insufficient balance"
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Request not found or user not found"
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation error"
     *     )
     * )
     */
    public function addTransactionHash(Request $request, $requestId)
    {
        $validator = Validator::make($request->all(), [
            'transaction_hash' => 'required|string|max:255'
        ]);
    
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
    
        $withdrawalRequest = WithdrawalRequest::findOrFail($requestId);
    
        if (!$withdrawalRequest->canBeUpdated()) {
            return response()->json([
                'message' => 'Cannot update completed request'
            ], 400);
        }
    
        // کم کردن amount_usd از capital_profit کاربر
        $user = User::where('user_id', $withdrawalRequest->user_id)->first();
        if (!$user) {
            return response()->json([
                'message' => 'User not found'
            ], 404);
        }
        if ($user->capital_profit < $withdrawalRequest->amount_usd) {
            return response()->json([
                'message' => 'Insufficient capital profit balance'
            ], 400);
        }
        $user->capital_profit -= $withdrawalRequest->amount_usd;
        $user->save();
    
        $withdrawalRequest->update([
            'transaction_hash' => $request->transaction_hash,
            'status' => WithdrawalRequest::STATUS_COMPLETED
        ]);
    
        return response()->json([
            'message' => 'Transaction hash added successfully',
            'withdrawal_request' => $withdrawalRequest
        ]);
    }

    /**
     * @OA\Get(
     *     path="/api/admin/withdrawal-requests",
     *     summary="Get all withdrawal requests (admin only)",
     *     tags={"Withdrawal Requests"},
     *     security={{"bearerAuth":{}}},
     *     @OA\Parameter(
     *         name="status",
     *         in="query",
     *         required=false,
     *         @OA\Schema(type="string", enum={"in_queue", "in_process", "completed"})
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="List of all withdrawal requests"
     *     )
     * )
     */
    public function adminIndex(Request $request)
    {
        $query = WithdrawalRequest::with('user');

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $requests = $query->orderBy('created_at', 'desc')->get();

        return response()->json(['withdrawal_requests' => $requests]);
    }
} 