<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * @OA\Post(
     *     path="/api/users/transfer-capital-to-gain",
     *     summary="Transfer from capital_profit to gain_profit",
     *     tags={"User"},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"user_id","amount"},
     *             @OA\Property(property="user_id", type="string", example="MC123456"),
     *             @OA\Property(property="amount", type="number", format="float", example=100)
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Transfer successful",
     *         @OA\JsonContent(
     *             @OA\Property(property="capital_profit", type="number"),
     *             @OA\Property(property="gain_profit", type="number")
     *         )
     *     ),
     *     @OA\Response(response=400, description="Insufficient capital_profit or invalid input"),
     *     @OA\Response(response=404, description="User not found")
     * )
     */
    public function transferCapitalToGain(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,user_id',
            'amount' => 'required|numeric|min:1',
        ]);

        $user = User::where('user_id', $request->user_id)->first();
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        if ($user->capital_profit < $request->amount) {
            return response()->json(['message' => 'Insufficient capital_profit'], 400);
        }

        $user->capital_profit -= $request->amount;
        $user->gain_profit += $request->amount;
        $user->save();

        return response()->json([
            'capital_profit' => $user->capital_profit,
            'gain_profit' => $user->gain_profit,
            'message' => 'Transfer successful'
        ]);
    }

    /**
     * @OA\Post(
     *     path="/api/users/transfer-to-user",
     *     summary="Transfer from your capital_profit or gain_profit to another user's same account",
     *     tags={"User"},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"from_user_id","to_user_id","amount","from_account"},
     *             @OA\Property(property="from_user_id", type="string", example="MC123456"),
     *             @OA\Property(property="to_user_id", type="string", example="MC654321"),
     *             @OA\Property(property="amount", type="number", format="float", example=100),
     *             @OA\Property(property="from_account", type="string", enum={"capital_profit","gain_profit"}, example="capital_profit")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Transfer successful",
     *         @OA\JsonContent(
     *             @OA\Property(property="from_user", type="object",
     *                 @OA\Property(property="user_id", type="string"),
     *                 @OA\Property(property="capital_profit", type="number"),
     *                 @OA\Property(property="gain_profit", type="number")
     *             ),
     *             @OA\Property(property="to_user", type="object",
     *                 @OA\Property(property="user_id", type="string"),
     *                 @OA\Property(property="capital_profit", type="number"),
     *                 @OA\Property(property="gain_profit", type="number")
     *             ),
     *             @OA\Property(property="message", type="string")
     *         )
     *     ),
     *     @OA\Response(response=400, description="Insufficient balance or invalid input"),
     *     @OA\Response(response=404, description="User not found")
     * )
     */
    public function transferToUser(Request $request)
    {
        $request->validate([
            'from_user_id' => 'required|exists:users,user_id',
            'to_user_id' => 'required|exists:users,user_id|different:from_user_id',
            'amount' => 'required|numeric|min:1',
            'from_account' => 'required|in:capital_profit,gain_profit',
        ]);

        $fromUser = User::where('user_id', $request->from_user_id)->first();
        $toUser = User::where('user_id', $request->to_user_id)->first();

        if (!$fromUser || !$toUser) {
            return response()->json(['message' => 'User not found'], 404);
        }

        if ($fromUser->{$request->from_account} < $request->amount) {
            return response()->json(['message' => 'Insufficient balance'], 400);
        }

        // انتقال مبلغ
        $fromUser->{$request->from_account} -= $request->amount;
        $toUser->{$request->from_account} += $request->amount;

        $fromUser->save();
        $toUser->save();

        return response()->json([
            'from_user' => [
                'user_id' => $fromUser->user_id,
                'capital_profit' => $fromUser->capital_profit,
                'gain_profit' => $fromUser->gain_profit,
            ],
            'to_user' => [
                'user_id' => $toUser->user_id,
                'capital_profit' => $toUser->capital_profit,
                'gain_profit' => $toUser->gain_profit,
            ],
            'message' => 'Transfer successful'
        ]);
    }

    /**
     * @OA\Get(
     *     path="/api/users/profile",
     *     summary="Get user profile information",
     *     tags={"User"},
     *     @OA\Parameter(
     *         name="user_id",
     *         in="query",
     *         required=true,
     *         description="User ID to get profile for",
     *         @OA\Schema(type="string", example="MC123456")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="User profile retrieved successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="user_id", type="string"),
     *             @OA\Property(property="email", type="string"),
     *             @OA\Property(property="registration_date", type="string", format="date-time"),
     *             @OA\Property(property="gain_profit", type="number", format="float"),
     *             @OA\Property(property="capital_profit", type="number", format="float"),
     *             @OA\Property(property="deposit_balance", type="number", format="float"),
     *             @OA\Property(property="level", type="integer", example=0)
     *         )
     *     ),
     *     @OA\Response(response=404, description="User not found")
     * )
     */
    public function profile(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,user_id',
        ]);

        $user = User::where('user_id', $request->user_id)->first();
        
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        return response()->json([
            'user_id' => $user->user_id,
            'email' => $user->email,
            'registration_date' => $user->created_at,
            'gain_profit' => $user->gain_profit,
            'capital_profit' => $user->capital_profit,
            'deposit_balance' => $user->deposit_balance,
            'level' => 0 // Currently fixed at 0 for all users
        ]);
    }
} 