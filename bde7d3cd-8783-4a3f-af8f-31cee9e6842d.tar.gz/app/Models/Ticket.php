<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'subject',
        'message',
        'admin_reply',
        'status',
    
        'admin_replied_at'
    ];

    protected $casts = [
   
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'admin_replied_at' => 'datetime',
    ];

    // Relationship with User
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'user_id');
    }

    // Status constants
    const STATUS_OPEN = 'open';
    const STATUS_CLOSE = 'close';
    const STATUS_PENDING = 'pending';
    const STATUS_IN_PROGRESS = 'in_progress';
    const STATUS_RESOLVED = 'resolved';
 


    // Helper method to check if ticket can be replied to
    public function canBeReplied()
    {
        return $this->status === self::STATUS_OPEN;
    }
} 