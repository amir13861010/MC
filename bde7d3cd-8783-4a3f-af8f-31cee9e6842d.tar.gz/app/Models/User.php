<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'first_name',
        'last_name',
        'user_id',
        'deposit_balance',
        'gain_profit',
        'capital_profit',
        'country',
        'mobile',
        'voucher_id',
        'friend_id'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'deposit_balance' => 'decimal:2',
        'gain_profit' => 'decimal:2',
        'capital_profit' => 'decimal:2',
    ];

    public function voucher()
    {
        return $this->belongsTo(Voucher::class);
    }

    public function parent()
    {
        return $this->belongsTo(User::class, 'friend_id', 'user_id');
    }

    public function subUsers()
    {
        return $this->hasMany(User::class, 'friend_id', 'user_id');
    }

    public function deposits()
    {
        return $this->hasMany(Deposit::class, 'user_id', 'user_id');
    }

    public function referrals()
    {
        return $this->hasMany(User::class, 'friend_id', 'user_id');
    }

    public static function generateUniqueUserId()
    {
        do {
            $userId = 'MC-' . str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
        } while (self::where('user_id', $userId)->exists());

        return $userId;
    }

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    public function getJWTCustomClaims()
    {
        return [];
    }

    /**
     * Check if user is admin
     */
    public function isAdmin()
    {
        return $this->role === 'admin';
    }
}
