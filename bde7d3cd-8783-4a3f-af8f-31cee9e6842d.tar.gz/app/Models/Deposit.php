<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Deposit extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'amount',
        'status'
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'created_at' => 'datetime',
        'updated_at' => 'datetime'
    ];

    // Status constants
    const STATUS_PENDING = 'pending';
    const STATUS_COMPLETED = 'completed';
    const STATUS_FAILED = 'failed';

    // Relationship with User
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'user_id');
    }

    /**
     * Process leg reward for the parent user when a deposit is completed.
     */
    public function processLegReward()
    {
        $user = $this->user;
        if (!$user || !$user->parent) return;

        $parent = $user->parent;
        // جلوگیری از اجرای دوباره با cache
        $logKey = 'reward_' . $parent->user_id . '_' . $this->id;
        if (cache()->has($logKey)) {
            return;
        }
        cache()->put($logKey, true, 60); // 60 دقیقه کافی است

        $referrals = $parent->referrals()->orderBy('created_at')->get();
        $legIndex = $referrals->search(function($ref) use ($user) {
            return $ref->id === $user->id;
        });
        if ($legIndex === false) return;

        $reward = \App\Models\Reward::where('user_id', $parent->user_id)->latest()->first();
        if (!$reward ||
            $reward->leg_a_balance >= 1500 || $reward->leg_b_balance >= 1500 || $reward->leg_c_balance >= 1500) {
            $reward = \App\Models\Reward::create([
                'user_id' => $parent->user_id,
                'leg_a_balance' => 0,
                'leg_b_balance' => 0,
                'leg_c_balance' => 0,
                'reward_amount' => 0,
                'is_rewarded' => false,
            ]);
        }

        $legA = $reward->leg_a_balance;
        $legB = $reward->leg_b_balance;
        $legC = $reward->leg_c_balance;

        $addable = 0;
        switch ($legIndex) {
            case 0:
                $addable = min(1500 - $legA, $this->amount);
                $legA += $addable;
                break;
            case 1:
                $addable = min(1500 - $legB, $this->amount);
                $legB += $addable;
                break;
            case 2:
                $addable = min(1500 - $legC, $this->amount);
                $legC += $addable;
                break;
            default:
                return;
        }

        $isRewarded = false;
        $rewardAmount = 0;
        if ($legA >= 1500 && $legB >= 1500 && $legC >= 1500 && !$reward->is_rewarded) {
            $isRewarded = true;
            $rewardAmount = 500;
            if ($reward->reward_amount == 0) {
                $parent->increment('deposit_balance', 500);
            }
        }

        $reward->update([
            'leg_a_balance' => $legA,
            'leg_b_balance' => $legB,
            'leg_c_balance' => $legC,
            'reward_amount' => $rewardAmount,
            'is_rewarded' => $isRewarded,
        ]);
    }

    public function processLegRewardForAllParents($amount = null, $user = null)
    {
        $user = $user ?: $this->user;
        if (!$user || !$user->parent) return;

        $parent = $user->parent;
        $referrals = $parent->referrals()->orderBy('created_at')->get();
        $legIndex = $referrals->search(function($ref) use ($user) {
            return $ref->id === $user->id;
        });
        if ($legIndex === false) return;

        // جلوگیری از اجرای دوباره با cache
        $logKey = 'reward_' . $parent->user_id . '_' . $this->id;
        if (cache()->has($logKey)) {
            return;
        }
        cache()->put($logKey, true, 60);

        $reward = \App\Models\Reward::where('user_id', $parent->user_id)->latest()->first();
        if (!$reward ||
            $reward->leg_a_balance >= 1500 || $reward->leg_b_balance >= 1500 || $reward->leg_c_balance >= 1500) {
            $reward = \App\Models\Reward::create([
                'user_id' => $parent->user_id,
                'leg_a_balance' => 0,
                'leg_b_balance' => 0,
                'leg_c_balance' => 0,
                'reward_amount' => 0,
                'is_rewarded' => false,
            ]);
        }

        $legA = $reward->leg_a_balance;
        $legB = $reward->leg_b_balance;
        $legC = $reward->leg_c_balance;

        $addable = 0;
        $depositAmount = $amount ?? $this->amount;
        switch ($legIndex) {
            case 0:
                $addable = min(1500 - $legA, $depositAmount);
                $legA += $addable;
                break;
            case 1:
                $addable = min(1500 - $legB, $depositAmount);
                $legB += $addable;
                break;
            case 2:
                $addable = min(1500 - $legC, $depositAmount);
                $legC += $addable;
                break;
            default:
                return;
        }

        $isRewarded = false;
        $rewardAmount = 0;
        if ($legA >= 1500 && $legB >= 1500 && $legC >= 1500 && !$reward->is_rewarded) {
            $isRewarded = true;
            $rewardAmount = 500;
            if ($reward->reward_amount == 0) {
                $parent->increment('deposit_balance', 500);
            }
        }

        $reward->update([
            'leg_a_balance' => $legA,
            'leg_b_balance' => $legB,
            'leg_c_balance' => $legC,
            'reward_amount' => $rewardAmount,
            'is_rewarded' => $isRewarded,
        ]);

        // بازگشتی برای والد بالاتر
        if ($parent->parent && $parent->id !== $user->id) {
            $this->processLegRewardForAllParents($depositAmount, $parent);
        }
    }

    protected static function booted()
    {
        static::created(function ($deposit) {
            if ($deposit->status === self::STATUS_COMPLETED) {
                $deposit->processLegRewardForAllParents();
            }
        });
    }
} 