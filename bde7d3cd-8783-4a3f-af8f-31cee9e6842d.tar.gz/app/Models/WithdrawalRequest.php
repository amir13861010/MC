<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WithdrawalRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'wallet_address',
        'amount_usd',
        'amount_btc',
        'comment',
        'status',
        'transaction_hash'
    ];

    protected $casts = [
        'amount_usd' => 'decimal:2',
        'amount_btc' => 'decimal:8',
        'created_at' => 'datetime',
        'updated_at' => 'datetime'
    ];

    // Relationship with User
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'user_id');
    }

    // Status constants
    const STATUS_IN_PROCESS = 'in_process';
    const STATUS_IN_QUEUE = 'in_queue';
    const STATUS_COMPLETED = 'completed';

    // Helper method to check if request can be updated
    public function canBeUpdated()
    {
        return $this->status !== self::STATUS_COMPLETED;
    }
} 